package com.namit.kumar.restrauntbooking.TheFB;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.namit.kumar.restrauntbooking.R;
import com.namit.kumar.restrauntbooking.Tablebooking;

public class TheFoodBarn extends AppCompatActivity {

    TextView review;
    TextView menu;
    TextView bookTable;
    TextView contact;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_food_barn);

        review = findViewById(R.id.Review);
        menu = findViewById(R.id.Menu);
        bookTable = findViewById(R.id.BookTable);
        contact = findViewById(R.id.Contact_Us);




        review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),ReviewFB.class));

            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        bookTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Tablebooking.class));
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder alert =new AlertDialog.Builder(TheFoodBarn.this);
                alert.setTitle("THE FOOD BARN");
                alert.setCancelable(false);
                alert.setMessage("CONTACT NO :- 9725463894\n LNMIIT");

                final AlertDialog dialog = alert.create();
                alert.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {


                    }
                });


            }
        });

    }
}
