package com.shaswat.kumar.restrauntbooking.Model;

public class ReviewData {

    String review;
    String id;

    String date;


    public ReviewData(){

    }

    public ReviewData(String rev, String id,String date){

        this.review = rev;
        this.id = id;
        this.date = date;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
