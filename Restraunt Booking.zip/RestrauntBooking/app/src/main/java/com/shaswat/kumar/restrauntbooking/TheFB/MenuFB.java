package com.shaswat.kumar.restrauntbooking.TheFB;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

import com.shaswat.kumar.restrauntbooking.R;

public class MenuFB extends AppCompatActivity {

    Toolbar menufb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_fb);

        menufb = findViewById(R.id.menufbtl);


        setSupportActionBar(menufb);
        getSupportActionBar().setTitle("MENU");

    }
}
