package com.shaswat.kumar.restrauntbooking.TenTwisters;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shaswat.kumar.restrauntbooking.Model.Data;
import com.shaswat.kumar.restrauntbooking.R;

import java.text.DateFormat;
import java.util.Date;

public class TableBookingTT extends AppCompatActivity {


    Boolean isClickedDummy1,isClickedDummy2,isClickedDummy3,isClickedDummy4,isClickedDummy5,isClickedDummy6,isClickedDummy7,isClickedDummy8,isClickedDummy9,isClickedDummy10,isClickedDummy11,isClickedDummy12;

    private FirebaseAuth mAuth;
    private DatabaseReference mBookingDatabase;


    public String table_noTT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_booking_tt);



        mAuth = FirebaseAuth.getInstance();
        FirebaseUser mUser = mAuth.getCurrentUser();
        String uid = mUser.getUid();



        mBookingDatabase = FirebaseDatabase.getInstance().getReference().child("BookingData").child(uid);

        mBookingDatabase.keepSynced(true);

        isClickedDummy1 = true;
        isClickedDummy2 = true;
        isClickedDummy3 = true;
        isClickedDummy4 = true;
        isClickedDummy5 = true;
        isClickedDummy6 = true;
        isClickedDummy7 = true;
        isClickedDummy8 = true;
        isClickedDummy9 = true;
        isClickedDummy10 = true;
        isClickedDummy11 = true;
        isClickedDummy12 = true;


        CardView t1 =(CardView)findViewById(R.id.table1TT);
        CardView t2 =(CardView)findViewById(R.id.table2TT);
        CardView t3 =(CardView)findViewById(R.id.table3TT);
        CardView t4 =(CardView)findViewById(R.id.table4TT);
        CardView t5 =(CardView)findViewById(R.id.table5TT);
        CardView t6 =(CardView)findViewById(R.id.table6TT);
        CardView t7 =(CardView)findViewById(R.id.table7TT);
        CardView t8 =(CardView)findViewById(R.id.table8TT);
        CardView t9 =(CardView)findViewById(R.id.table9TT);
        CardView t10 =(CardView)findViewById(R.id.table10TT);
        CardView t11 =(CardView)findViewById(R.id.table11TT);
        CardView t12 =(CardView)findViewById(R.id.table12TT) ;



        t1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy1) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "1";
                    Information();
                    isClickedDummy1 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy1 = true;
                }
            }
        });

        t2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy2) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));

                    table_noTT = "2";
                    Information();

                    isClickedDummy2 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy2 = true;
                }
            }
        });

        t3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy3) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "3";
                    Information();
                    isClickedDummy3 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy3 = true;
                }
            }
        });

        t4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy4) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "4";
                    Information();
                    isClickedDummy4 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy4 = true;
                }
            }
        });

        t5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy5) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "5";
                    Information();
                    isClickedDummy5 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy5 = true;
                }
            }
        });

        t6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy6) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "6";
                    Information();
                    isClickedDummy6 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy6 = true;
                }
            }
        });

        t7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy7) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "7";
                    Information();
                    isClickedDummy7 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy7 = true;
                }
            }
        });
        t8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy8) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "8";
                    Information();
                    isClickedDummy8 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy8 = true;
                }
            }
        });
        t9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy9) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "9";
                    Information();
                    isClickedDummy9 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy9 = true;
                }
            }
        });



        t10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy10) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "10";
                    Information();
                    isClickedDummy10 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy10 = true;
                }
            }
        });

        t11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy11) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "11";
                    Information();
                    isClickedDummy11 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy11 = true;
                }
            }
        });

        t12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isClickedDummy12) {
                    v.setBackgroundColor(Color.parseColor("#FF0000"));
                    table_noTT= "12";
                    Information();
                    isClickedDummy12 = false;
                } else {
                    v.setBackgroundColor(Color.parseColor("#FFFFFF"));
                    isClickedDummy12 = true;
                }
            }
        });

    }
    public void Information(){





        final Dialog dialog = new Dialog(this);

        dialog.setContentView(R.layout.customer_informtion);



        final EditText Name = dialog.findViewById(R.id.amount_edt);

        Button btnSave = dialog.findViewById(R.id.confirm);
        Button btnCancel = dialog.findViewById(R.id.btnCancel);

        dialog.show();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = "TEN TWISTERS";

                if(TextUtils.isEmpty(name)){
                    Name.setError("Required Field..");
                    return;
                }


                String id = mBookingDatabase.push().getKey();//creates a random id in mIncomeDatabase

                String mDate = DateFormat.getDateInstance().format(new Date());

                Data data = new Data(name,id,mDate,table_noTT);

                mBookingDatabase.child(id).setValue(data);

                Toast.makeText(getApplicationContext(),"Table Booked", Toast.LENGTH_SHORT).show();



                dialog.dismiss();



            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



            }
        });


    }
}
