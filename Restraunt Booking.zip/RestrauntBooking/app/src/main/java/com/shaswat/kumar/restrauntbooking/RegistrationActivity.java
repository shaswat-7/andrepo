package com.shaswat.kumar.restrauntbooking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegistrationActivity extends AppCompatActivity {


    private EditText mEmail_reg;
    private EditText mPassword_reg;
    private EditText mConfirmPassword;
    private Button mButton_reg;
    private TextView mSignin_reg;

    //Firebase

    private FirebaseAuth mAuth;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);


        mDialog = new ProgressDialog(this);

        mAuth = FirebaseAuth.getInstance();
        registrationFunction();
    }

    public void registrationFunction(){

        mEmail_reg = findViewById(R.id.email_reg);
        mPassword_reg = findViewById(R.id.password_reg);
        mButton_reg = findViewById(R.id.btn_reg);
        mSignin_reg = findViewById(R.id.singin_reg);
        mConfirmPassword = findViewById(R.id.confirm_password_reg);



        mButton_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = mEmail_reg.getText().toString().trim();
                String password = mPassword_reg.getText().toString().trim();
                String confirmPassword = mConfirmPassword.getText().toString().trim();



                if(TextUtils.isEmpty(email)){
                    mEmail_reg.setError("Required Field..");
                    return;
                }

                if(TextUtils.isEmpty(password)){
                    mPassword_reg.setError("Required Field..");
                    return;
                }

                if(!password.equals(confirmPassword)){
                    mConfirmPassword.setError("Password is not same");
                    return;
                }

                mDialog.setMessage("Processing..");
                mDialog.show();

                mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){
                            mDialog.dismiss();
                            startActivity(new Intent(getApplicationContext(),RestaurantOpt.class));
                            Toast.makeText(getApplicationContext(),"Registation Complete..",Toast.LENGTH_SHORT).show();
                        } else{
                            mDialog.dismiss();
                            Toast.makeText(getApplicationContext(),"Registation Failed..",Toast.LENGTH_SHORT).show();
                        }



                    }
                });



            }
        });

        mSignin_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
            }
        });

    }
}
