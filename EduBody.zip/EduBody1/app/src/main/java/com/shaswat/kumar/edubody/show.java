package com.shaswat.kumar.edubody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class show extends AppCompatActivity {

    LinearLayout sem1Button;
    LinearLayout sem2Button;
    LinearLayout sem3Button;
    LinearLayout sem4Button;
    LinearLayout sem5Button;
    LinearLayout sem6Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        sem1Button = findViewById(R.id.Sem1Layout);
        sem2Button = findViewById(R.id.Semester2Layout);
        sem3Button = findViewById(R.id.Semester3Layout);
        sem4Button = findViewById(R.id.Semester4Layout);
        sem5Button = findViewById(R.id.Semester5Layout);
        sem6Button = findViewById(R.id.Semester6Layout);


        ClickEvents();

    }

    public void ClickEvents(){

        sem1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(),Sem1Activity.class);
                startActivity(intent);

            }
        });


        sem2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(),Sem2Activity.class);
                startActivity(intent);

            }
        });


        sem3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });



        sem4Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


        sem5Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        sem6Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }




}
