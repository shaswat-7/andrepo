package com.shaswat.kumar.edubody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class python extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_python);
        TextView txt1 =(TextView)findViewById(R.id.instalth);
        TextView txt2 =(TextView)findViewById(R.id.instalvi);
        TextView txt3 =(TextView)findViewById(R.id.datatypesth);
        TextView txt4 =(TextView)findViewById(R.id.datatypesvideo);
        TextView txt5 =(TextView)findViewById(R.id.operatorsth);
        TextView txt6 =(TextView)findViewById(R.id.operatorsvideo);
        TextView txt7 =(TextView)findViewById(R.id.statementth);
        TextView txt8 =(TextView)findViewById(R.id.statementvideo);
        TextView txt9 =(TextView)findViewById(R.id.loopth);
        TextView txt10 =(TextView)findViewById(R.id.loopvid1);
        TextView txt11 =(TextView)findViewById(R.id.loopvid2);
        TextView txt12 =(TextView)findViewById(R.id.loopvid3);
        TextView txt13 =(TextView)findViewById(R.id.loopvid4);
        TextView txt14 =(TextView)findViewById(R.id.listth);
        TextView txt15 =(TextView)findViewById(R.id.listvid1);
        TextView txt16 =(TextView)findViewById(R.id.listvid2);
        TextView txt17 =(TextView)findViewById(R.id.funth);
        TextView txt18 =(TextView)findViewById(R.id.funvid1);
        TextView txt19 =(TextView)findViewById(R.id.funvid2);
        TextView txt20 =(TextView)findViewById(R.id.argsth);
        TextView txt21 =(TextView)findViewById(R.id.argsvid1);
        TextView txt22 =(TextView)findViewById(R.id.argsvid2);
        TextView txt23 =(TextView)findViewById(R.id.lamdath);
        TextView txt24 =(TextView)findViewById(R.id.lamdavid1);
        TextView txt25 =(TextView)findViewById(R.id.lamdavid2);
        TextView txt26 =(TextView)findViewById(R.id.oopsth1);
        TextView txt27 =(TextView)findViewById(R.id.oopsth2);
        TextView txt28 =(TextView)findViewById(R.id.oopsvid1);
        TextView txt29 =(TextView)findViewById(R.id.oopsvid2);


        txt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://wiki.python.org/moin/BeginnersGuide/Download"));
                startActivity(intent);

            }
        });


        txt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=LrMOrMb8-3s"));
                startActivity(intent);

            }
        });
        txt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.programiz.com/python-programming/variables-datatypes"));
                startActivity(intent);

            }
        });
        txt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=6yrsX752CWk"));
                startActivity(intent);

            }
        });

        txt5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.geeksforgeeks.org/basic-operators-python/"));
                startActivity(intent);

            }
        });

        txt6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(" https://www.youtube.com/watch?v=v5MR5JnKcZI"));
                startActivity(intent);

            }
        });

        txt7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.datacamp.com/community/tutorials/python-if-elif-else"));
                startActivity(intent);

            }
        });

        txt8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=AWek49wXGzI"));
                startActivity(intent);

            }
        });

        txt9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.learnpython.org/en/Loops"));
                startActivity(intent);

            }
        });


        txt10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=KBOlvpmtl-o"));
                startActivity(intent);

            }
        });


        txt11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=oYTWPVAEvXs"));
                startActivity(intent);

            }
        });


        txt12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=OnDr4J2UXSA"));
                startActivity(intent);

            }
        });


        txt13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=6TEGxJXLAWQ"));
                startActivity(intent);

            }
        });


        txt14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.pythonforbeginners.com/basics/list-comprehensions-in-python"));
                startActivity(intent);

            }
        });


        txt15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=VdC_g1pmfNc"));
                startActivity(intent);

            }
        });


        txt16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=AhSvKGTh28Q"));
                startActivity(intent);

            }
        });


        txt17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("Site-https://www.learnpython.org/en/Functions"));
                startActivity(intent);

            }
        });


        txt18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=5xXUXgxlsi8"));
                startActivity(intent);

            }
        });


        txt19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=9Os0o3wzS_I"));
                startActivity(intent);

            }
        });


        txt20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.digitalocean.com/community/tutorials/how-to-use-args-and-kwargs-in-python-3"));
                startActivity(intent);

            }
        });



        txt21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=37EaS1sAeUo"));
                startActivity(intent);

            }
        });

        txt22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=762mFeD2SlU"));
                startActivity(intent);

            }
        });

        txt23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.programiz.com/python-programming/anonymous-function"));
                startActivity(intent);

            }
        });

        txt24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=EZcLZfGXDQY"));
                startActivity(intent);

            }
        });

        txt25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=Ob9rY6PQMfI"));
                startActivity(intent);

            }
        });

        txt26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.programiz.com/python-programming/object-oriented-programming"));
                startActivity(intent);

            }
        });

        txt27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://realpython.com/python3-object-oriented-programming/"));
                startActivity(intent);

            }
        });

        txt28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=fpdwRofNMeQ&list=PLu0W_9lII9ahfRrhFcoB-4lpp9YaBmdCP"));
                startActivity(intent);

            }
        });

        txt29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.youtube.com/watch?v=ZDa-Z5JzLYM&list=PL-osiE80TeTsqhIuOqKhwlXsIBIdSeYtc"));
                startActivity(intent);

            }
        });


    }
}
